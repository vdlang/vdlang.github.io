The Visually Descriptive Language (VDL) corpus
==============================================
http://vdlang.github.io/


Version history
===============
R20190521    21/05/2019    Initial release


Citation
========
If you use this dataset, please cite both the following works:

Tarfah Alrashid, Josiah Wang, Robert Gaizauskas
Annotating and Recognising Visually Descriptive Language
In Proceedings of the 15th Joint ACL - ISO Workshop on Interoperable Semantic Annotation (ISA-15), 2019.

Robert Gaizauskas, Josiah Wang, Arnau Ramisa
Defining Visually Descriptive Language
In Proceedings of the Fourth Workshop on Vision and Language (VL'15), 2015.

LaTeX
-----
@InProceedings{AlrashidEtAl:2019:ISA,
  author    = {Alrashid, Tarfah and Wang, Josiah and Gaizauskas, Robert},
  title     = {Annotating and Recognising Visually Descriptive Language},
  booktitle = {Proceedings of the 15th {{Joint ACL}} - {{ISO Workshop}} on {{Interoperable Semantic Annotation}} ({{ISA}}-15)},
  publisher = {{Tilburg Center for Cognition and Communication, Tilburg University, The Netherlands}},
  editor    = {Bunt, Harry},
  month     = may,
  year      = {2019},
  pages     = {22-32},  
  address   = {Gothenburg, Sweden},
  isbn      = {978-90-74029-38-4}
}

@InProceedings{GaizauskasEtAl:2015:VL,
  author    = {Gaizauskas, Robert and Wang, Josiah and Ramisa, Arnau},
  title     = {Defining Visually Descriptive Language},
  booktitle = {Proceedings of the Fourth Workshop on Vision and Language},
  month     = {September},
  year      = {2015},
  address   = {Lisbon, Portugal},
  publisher = {Association for Computational Linguistics},
  pages     = {10--17},
  url       = {http://aclweb.org/anthology/W15-2805}
}


Information
===========
This ZIP archive contains the corpus and segment-level annotations of Visually Descriptive Langauge (VDL) (Gaizauskas et al. 2015) for six text samples from the Brown Corpus (Brown) and eight chapters from The Wonderful Wizard of Oz (WOZ). 

The original annotations described in our VL'15 paper (Gaizuaskas et al. 2015) comprise all six samples from Brown and two chapters (7 and 9) from WOZ. The former was annotated by two of the authors, and the latter by all three authors.

Our ISA-15 (2019) paper extends the WOZ annotations to eight chapters in total (1, 3, 5, 7, 9, 11, 13, and 15), each annotated by two new external annotators who are not directly involved in developing the definition and guidelines. Thus, Chapters 7 and 9 are annotated by five annotators overall (including the previous three annotations).


Files
=====
+ RXXXXXXXX/[brown|woz]/corpus

The text of the corpus, one sentence per line.


+ RXXXXXXXX/[brown|woz]/annotations/brat/*

Segment-level annotations in the format provided by brat rapid annotation tool (https://brat.nlplab.org).
VDL segments are annotated as: 
    T* \t VDL startPosition endPosition \t segment
Impure VDL (IVDL) are implicitly annotated with multiple segments: 
    T* \t VDL startPosition1 endPosition1;startPosition2 endPosition2 \t segment
User notes/comments are annotated as:
    #* \t AnnotatorNotes T* \t Comments


+ RXXXXXXXX/[brown|woz]/annotations/sentlevel/*

Sentence-level annotations, inferred from the segment-level annotations.
One annotation per line, for each corresponding sentence in the corpus (see [brown|woz]/corpus)
0: Not VDL
1: Fully VDL
2: Partially VDL 


+ RXXXXXXXX/[brown|woz]/annotations/visualisation/*.htm

HTML visualisations of the segment-level annotations.



Contact
=======
For any enquiries please contact Josiah Wang (http://www.josiahwang.com/).

